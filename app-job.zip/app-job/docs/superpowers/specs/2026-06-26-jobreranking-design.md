# Job Candidate Ranking System — Design Spec
**Date:** 2026-06-26  
**Project:** jobreranking (India Runs Data & AI Challenge)  
**Goal:** Production-ready AI system that ranks 100k candidates against a job description the way a great recruiter would — beyond keyword matching, using semantic understanding, multi-dimensional fit scoring, and holistic LLM judgment.

---

## 1. Problem Statement

Recruiters miss the right candidates not because the talent isn't there, but because keyword filters can't understand context. A backend engineer who built production ML pipelines is a strong fit for an ML role even if they don't list "Machine Learning Engineer" as their title. This system addresses that by:

1. Building a semantic mental model of the ideal candidate from the JD (not just extracting keywords)
2. Matching candidates against that mental model across multiple independent dimensions
3. Blending structured platform signals (engagement, responsiveness, verification) with semantic fit
4. Using an LLM as a final holistic judge with explainable reasoning per candidate

**Input:** One job description + 100,000 candidate profiles (NDJSON, ~487MB)  
**Output:** Top 100 ranked candidates as `candidate_id, rank, score, reasoning` CSV

---

## 2. Dataset

- **candidates.json**: 100,000 candidates, one JSON object per line (NDJSON)
- Each candidate has: `profile`, `career_history` (up to 10 roles), `education`, `skills` (name + proficiency + endorsements + duration_months), `certifications`, `languages`, `redrob_signals` (23 platform signals)
- **redrob_signals** include: profile completeness, open-to-work flag, last active date, recruiter response rate, avg response time, skill assessment scores, GitHub activity score, notice period, salary expectations, preferred work mode, willing to relocate, interview completion rate, offer acceptance rate, verification flags
- **Submission format**: CSV with header `candidate_id,rank,score,reasoning`, exactly 100 rows, ranks 1–100 unique, scores non-increasing by rank

---

## 3. Architecture Overview

Five stages with Stage 1 and Stage 2 running in parallel:

```
JD ──────────────────────────────────────────────────────────────────┐
  │                                                                   │
  ├──► Stage 1: miniLM Broad Pre-filter ─────────────────────────►  │
  │    (raw JD → embed → cosine vs 100k → top 2500)                  │
  │                                                                   ▼
  └──► Stage 2: Gemini Flash Recruiter ──────────────────► Stage 3: Gemma Multi-dim Re-scoring
       (JD → Ideal Candidate Profile JSON)                 (ideal profile × top-2500 → composite)
                                                                      │
                                                                      ▼
                                                           Stage 4: Redrob Signal Blending
                                                           (semantic + structured → top 150)
                                                                      │
                                                                      ▼
                                                           Stage 5: Gemini Pro Final Ranking
                                                           (holistic re-rank + reasoning → top 100)
                                                                      │
                                                                      ▼
                                                           submission.csv
```

**Key differentiator:** The semantic target in Stage 3 is the LLM's *mental model of the ideal candidate* — not the raw JD. This captures inferred signals ("should have transitioned from data engineering to ML") that raw JD text buries.

---

## 4. Stage-by-Stage Design

### Stage 1 — miniLM Broad Pre-filter

**Purpose:** Eliminate clear outliers from 100k → ~2500. Fast and cheap — no LLM, no API cost.

**Model:** `sentence-transformers/all-MiniLM-L6-v2` (local)

**Query text:** Raw JD text (single embed, no transformation)

**Candidate text per candidate:**
```
{headline} | {summary} | {career_history[0..2].description joined} | {skills[].name joined}
```

**Index:** FAISS flat index (L2 or cosine). Built once offline, saved to `cache/embeddings_cache/`.

**Output:** List of top-2500 `candidate_id`s by cosine similarity to JD.

**Runs in parallel with Stage 2** — no dependency between them.

---

### Stage 2 — LLM Recruiter / Ideal Candidate Profile

**Purpose:** Transform raw JD into a structured recruiter mental model used as the semantic target in Stage 3.

**Model:** `gemini-2.5-flash`

**Input:** Full job description text

**Output (structured JSON):**
```json
{
  "required_skills": ["string"],
  "preferred_skills": ["string"],
  "experience_requirements": {
    "min_years": 0,
    "seniority": "mid/senior/lead",
    "domains": ["string"],
    "trajectory_signals": ["string describing growth patterns that indicate fit"]
  },
  "red_flags": ["string"],
  "soft_signals": {
    "summary_traits": ["string"],
    "activities_and_awards": ["string"],
    "certifications": ["string"]
  },
  "dimension_weights": {
    "skills": 0.4,
    "experience": 0.4,
    "soft_signals": 0.2
  }
}
```

**Prompt location:** `prompts/ideal_candidate.txt`

**Caching:** Output saved to `cache/ideal_profile_cache.json` — re-used across runs without re-calling the LLM unless the JD changes.

**Validation:** Pydantic model `models/ideal_profile.py` validates the JSON output before Stage 3 uses it. If LLM returns malformed JSON, retry once with a stricter prompt.

---

### Stage 3 — Gemma 300M Multi-dimensional Re-scoring

**Purpose:** Score each candidate in top-2500 across 3 independent semantic dimensions against the ideal profile.

**Model:** `google/gemma-3-300M` loaded locally via HuggingFace Transformers (mean-pooled last hidden state as embedding)

**3 query embeddings** (built from Stage 2 ideal profile JSON):
| Dimension | Query text constructed from |
|---|---|
| Skills | `required_skills + preferred_skills` flattened to comma-separated text |
| Experience | `experience_requirements.domains + trajectory_signals + seniority` as narrative |
| Soft Signals | `soft_signals.summary_traits + activities_and_awards + certifications` as narrative |

**3 candidate embeddings per candidate:**
| Dimension | Candidate text constructed from |
|---|---|
| Skills | `skills[].name + proficiency + duration_months` + `redrob_signals.skill_assessment_scores` keys |
| Experience | Full `career_history[].description + title + industry` + `years_of_experience` + `current_title` |
| Soft Signals | `profile.summary` + `certifications[].name` + `languages` + `education[].field_of_study + tier` |

**Candidate embeddings** for top-2500 are pre-computed and cached in `cache/gemma_cache/` (3 numpy arrays per candidate dimension, indexed by candidate_id).

**Composite score:**
```
semantic_composite = w_skills × cosine(q_skills, c_skills)
                   + w_exp    × cosine(q_exp,    c_exp)
                   + w_soft   × cosine(q_soft,   c_soft)
```
Where `w_skills`, `w_exp`, `w_soft` come from Stage 2's `dimension_weights`.

**Output:** Top-2500 candidates with `semantic_composite` score, sorted descending.

---

### Stage 4 — Redrob Signal Blending

**Purpose:** Blend semantic fit with platform engagement and logistics signals to surface candidates who are both a good fit and actually reachable/hireable.

**6 sub-signal scores** (each normalized 0–1):

| Sub-signal | Fields used | Logic |
|---|---|---|
| `engagement_score` | `open_to_work_flag`, `last_active_date`, `applications_submitted_30d` | Weighted: open_to_work (0.4) + recency (0.4) + activity (0.2) |
| `responsiveness_score` | `recruiter_response_rate`, `avg_response_time_hours`, `interview_completion_rate` | High response rate + low response time + high interview completion |
| `credibility_score` | `verified_email`, `verified_phone`, `linkedin_connected`, `profile_completeness_score` | Sum of verification flags + completeness normalized |
| `market_signal_score` | `saved_by_recruiters_30d`, `search_appearance_30d` | Log-normalized (prevent outlier dominance) |
| `technical_signal_score` | `github_activity_score`, `skill_assessment_scores` average | Average; github_activity_score=-1 treated as 0 |
| `logistics_score` | `notice_period_days`, `willing_to_relocate`, `preferred_work_mode` vs JD | Penalty for notice >90 days; bonus for relocation willingness if JD requires it |

**Redrob composite:**
```
redrob_score = 0.25×engagement + 0.25×responsiveness + 0.20×credibility
             + 0.10×market_signal + 0.10×technical_signal + 0.10×logistics
```

**Final blended score:**
```
blended_score = 0.65 × semantic_composite + 0.35 × redrob_score
```

**Output:** Top 150 candidates by blended score.

**Data validation:** Candidates with `profile_completeness_score < 30` or `last_active_date > 180 days ago` are flagged as low-quality and capped at rank 90+ unless semantic score is exceptionally high (>0.90).

---

### Stage 5 — Gemini Pro Final Ranking

**Purpose:** Holistic final judgment by an LLM acting as a senior recruiter. Re-orders top 150 into final top 100 and generates reasoning per candidate.

**Model:** `gemini-2.5-pro-preview`

**Input per candidate (condensed, not full JSON):**
- `candidate_id`, `current_title`, `years_of_experience`, `headline`
- Top 5 skills with proficiency
- Career trajectory summary (last 2 roles, titles, industries)
- `semantic_composite` score + per-dimension breakdown
- `redrob_score` + key sub-signals (engagement, responsiveness, credibility)
- Any red flags from Stage 2 matching

**Batching:** 50 candidates per LLM call (3 calls for 150 candidates), then a merge/final-sort pass on the 3 batches with a 4th LLM call that sees only the top ~30 from each batch.

**Prompt location:** `prompts/final_ranking.txt`

**Output per candidate:**
```json
{
  "candidate_id": "CAND_0000001",
  "rank": 1,
  "score": 0.94,
  "reasoning": "Strong ML trajectory with 6.9 years; Spark/Airflow data infra directly relevant; active GitHub; responds to recruiters within 24h."
}
```

**Hallucination prevention:** Reasoning strings are constrained to only reference fields present in the input. The prompt explicitly instructs: "Only cite facts present in the candidate data provided. Do not infer or invent achievements."

**Output:** Final list of 100 candidates → `formatter.py` writes `submission.csv`.

---

## 5. Data Flow & Intermediate Artifacts

```
candidates.json (100k NDJSON)
    → data/loader.py (streaming, no full load into RAM)
    → data/candidate_texts.py (builds 3 text blobs per candidate)
    → embeddings/minilm_encoder.py → cache/embeddings_cache/*.npy  [once]
    → embeddings/gemma_encoder.py  → cache/gemma_cache/*.npy       [once, top-2500 only]
    → pipeline/stage3_reranker.py  → scored_candidates.json        [runtime]
    → pipeline/stage4_signal_blender.py → top150.json              [runtime]
    → pipeline/stage5_llm_ranker.py → final100.json                [runtime]
    → output/formatter.py → submission.csv                         [final output]
```

---

## 6. Explainability & Data Validation

**Explainability:**
- Every candidate in the final 100 has a per-dimension score breakdown (`skills_score`, `experience_score`, `soft_signals_score`, `redrob_score`) stored in `final100.json`
- The `reasoning` field in the CSV is generated by the LLM constrained to cite only input facts
- The `dimension_weights` used for scoring are logged alongside the ideal profile — a recruiter can inspect why skills were weighted 0.4 vs experience 0.4
- Stage 2 ideal profile JSON is human-readable and auditable

**Data validation:**
- Pydantic models at every stage boundary catch malformed inputs before they corrupt scores
- Candidates with suspicious profiles (completeness <30, inactive >180 days, all verification flags false) are flagged and rank-capped
- `redrob_signals.offer_acceptance_rate = -1` (no history) treated as neutral (0.5), not penalized
- `github_activity_score = -1` (no GitHub) treated as 0, not penalized
- Submission validated via `output/validator.py` before writing — catches duplicate ranks, non-monotonic scores, malformed IDs

---

## 7. Models & Dependencies

| Component | Model/Library | Source |
|---|---|---|
| Stage 1 embedding | `all-MiniLM-L6-v2` | HuggingFace / sentence-transformers |
| Stage 1 index | FAISS | Meta (pip: faiss-cpu) |
| Stage 2 LLM | `gemini-2.5-flash` | Google Generative AI API |
| Stage 3 embedding | `google/gemma-3-300M` | HuggingFace Transformers (local) |
| Stage 5 LLM | `gemini-2.5-pro-preview` | Google Generative AI API |
| Schema validation | Pydantic v2 | pip |
| Data loading | ijson (streaming) | pip |

**Environment variables (`.env`):**
```
GOOGLE_API_KEY=...
GEMINI_FLASH_MODEL=gemini-2.5-flash
GEMINI_PRO_MODEL=gemini-2.5-pro-preview
MINILM_MODEL=sentence-transformers/all-MiniLM-L6-v2
GEMMA_MODEL=google/gemma-3-300M
PREFILTER_TOP_N=2500
FINAL_CANDIDATES_N=150
```

---

## 8. Codebase Structure

```
jobreranking/
│
├── main.py                          # Orchestrates all 5 stages
├── config.py                        # All config from env vars + defaults
│
├── pipeline/
│   ├── stage1_prefilter.py          # miniLM broad filter → top-2500
│   ├── stage2_ideal_profile.py      # Gemini Flash → ideal candidate JSON
│   ├── stage3_reranker.py           # Gemma 300M multi-dim → composite score
│   ├── stage4_signal_blender.py     # Redrob signal scoring + blend
│   └── stage5_llm_ranker.py         # Gemini Pro final ranking + reasoning
│
├── embeddings/
│   ├── minilm_encoder.py            # sentence-transformers MiniLM wrapper
│   ├── gemma_encoder.py             # local Gemma 300M wrapper (mean pool)
│   └── faiss_index.py               # FAISS index build, save, load, query
│
├── models/
│   ├── candidate.py                 # Pydantic: full candidate schema
│   ├── ideal_profile.py             # Pydantic: Stage 2 LLM output schema
│   └── scoring.py                   # Pydantic: intermediate score objects
│
├── data/
│   ├── loader.py                    # ijson streaming loader for NDJSON
│   └── candidate_texts.py           # Builds 3 text blobs per candidate
│
├── scoring/
│   ├── composite.py                 # Weighted composite from 3 cosine scores
│   └── redrob_signals.py            # 6 sub-signal scorers + normalizers
│
├── output/
│   ├── formatter.py                 # Builds submission CSV
│   └── validator.py                 # Validates CSV before writing
│
├── cache/
│   ├── embeddings_cache/            # MiniLM embeddings (numpy .npy)
│   ├── gemma_cache/                 # Gemma embeddings per dimension
│   └── ideal_profile_cache.json     # Cached ideal profile
│
├── prompts/
│   ├── ideal_candidate.txt          # Stage 2 prompt template
│   └── final_ranking.txt            # Stage 5 prompt template
│
├── scripts/
│   ├── precompute_embeddings.py     # One-time offline embedding of 100k candidates
│   └── validate.py                  # Run validator on output CSV
│
├── tests/
│   ├── test_stage1.py
│   ├── test_stage2.py
│   ├── test_stage3.py
│   ├── test_stage4.py
│   ├── test_stage5.py
│   └── test_output.py
│
├── .env.example
├── requirements.txt
└── README.md
```

---

## 9. Running the System

```bash
# Step 1 (one-time): Pre-compute all embeddings offline
python scripts/precompute_embeddings.py --candidates candidates.json

# Step 2: Run full pipeline
python main.py --jd job_description.txt --output submission.csv

# Step 3: Validate output
python scripts/validate.py submission.csv
```

**Estimated runtime after precompute:**
- Stage 1: ~5s (FAISS query on cached index)
- Stage 2: ~10s (one Gemini Flash call)
- Stage 3: ~60s (2500 × 3 cosine operations on cached Gemma embeddings)
- Stage 4: ~2s (pure Python scoring)
- Stage 5: ~45s (4 Gemini Pro calls)
- **Total: ~2 minutes** per JD after precompute

**Precompute runtime:** ~30–60 minutes for 100k candidates on CPU (MiniLM + Gemma 300M batched)
