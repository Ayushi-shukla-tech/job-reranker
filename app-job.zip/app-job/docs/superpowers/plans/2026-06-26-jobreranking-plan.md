# Job Candidate Ranking System — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a 5-stage AI pipeline that ranks 100k candidates against a job description using semantic understanding, multi-dimensional embedding fit, Redrob signal blending, and LLM holistic judgment — outputting a valid `submission.csv`.

**Architecture:** Stage 1 (miniLM broad pre-filter) and Stage 2 (Gemini Flash ideal profile generation) run in parallel. Their outputs converge at Stage 3 (Gemma 300M multi-dimensional re-scoring), followed by Stage 4 (Redrob signal blending) and Stage 5 (Gemini Pro final ranking + reasoning).

**Tech Stack:** Python 3.11+, sentence-transformers, faiss-cpu, HuggingFace Transformers (Gemma 300M), google-generativeai, Pydantic v2, ijson, numpy, pytest

## Global Constraints

- Python 3.11+ only
- All model names, weights, thresholds configurable via `config.py` / `.env` — never hardcoded in pipeline files
- Candidate data loaded via streaming (ijson) — never load all 100k into RAM at once
- Pydantic v2 models at every stage boundary — no raw dicts passed between stages
- `google/gemma-3-300M` runs locally via HuggingFace — no external API for embeddings
- Gemini models: `gemini-2.5-flash` (Stage 2), `gemini-2.5-pro-preview` (Stage 5)
- FAISS index and all embeddings cached to disk — precompute once, reuse across runs
- Submission CSV must pass `validate_submission.py` — exactly 100 rows, ranks 1–100 unique, scores non-increasing
- `github_activity_score = -1` → treat as 0 (no GitHub linked, not a penalty)
- `offer_acceptance_rate = -1` → treat as 0.5 neutral (no history)
- All tests in `tests/` using pytest

---

## File Map

| File | Responsibility |
|---|---|
| `config.py` | All env var loading + defaults (model names, thresholds, weights) |
| `models/candidate.py` | Pydantic model for full candidate schema |
| `models/ideal_profile.py` | Pydantic model for Stage 2 LLM output |
| `models/scoring.py` | Pydantic models for CandidateScore, FinalRankedCandidate |
| `data/loader.py` | Streaming NDJSON loader → yields validated Candidate objects |
| `data/candidate_texts.py` | Builds 3 text blobs per candidate (skills, experience, soft_signals) |
| `embeddings/minilm_encoder.py` | Wraps sentence-transformers MiniLM — encode text → np.ndarray |
| `embeddings/gemma_encoder.py` | Wraps local Gemma 300M — encode text → np.ndarray (mean pool) |
| `embeddings/faiss_index.py` | FAISS flat index: build, save to disk, load from disk, query top-N |
| `scoring/redrob_signals.py` | 6 sub-signal scorers, each 0–1 normalized + redrob composite |
| `scoring/composite.py` | Weighted cosine composite from 3 dimension scores |
| `pipeline/stage1_prefilter.py` | miniLM: embed JD → query FAISS index → return top-N candidate_ids |
| `pipeline/stage2_ideal_profile.py` | Gemini Flash: JD → IdealProfile JSON (with cache + retry) |
| `pipeline/stage3_reranker.py` | Gemma: embed ideal profile dims + candidates → composite scores |
| `pipeline/stage4_signal_blender.py` | Blend semantic + Redrob scores → top-150 CandidateScore list |
| `pipeline/stage5_llm_ranker.py` | Gemini Pro: batched ranking + reasoning → FinalRankedCandidate list |
| `output/formatter.py` | FinalRankedCandidate list → submission.csv |
| `output/validator.py` | Validate submission.csv against challenge rules |
| `prompts/ideal_candidate.txt` | Stage 2 system + user prompt template |
| `prompts/final_ranking.txt` | Stage 5 system + user prompt template |
| `scripts/precompute_embeddings.py` | CLI: embed all 100k candidates offline → save to cache/ |
| `main.py` | Orchestrates all 5 stages with parallel Stage 1+2 via asyncio |
| `.env.example` | Template for required env vars |
| `requirements.txt` | All dependencies pinned |

---

## Task 1: Project Scaffold + Config

**Files:**
- Create: `config.py`
- Create: `.env.example`
- Create: `requirements.txt`
- Create: `prompts/ideal_candidate.txt`
- Create: `prompts/final_ranking.txt`
- Create: `cache/embeddings_cache/.gitkeep`
- Create: `cache/gemma_cache/.gitkeep`
- Test: `tests/test_config.py`

**Interfaces:**
- Produces: `config.settings` object with fields: `google_api_key: str`, `gemini_flash_model: str`, `gemini_pro_model: str`, `minilm_model: str`, `gemma_model: str`, `prefilter_top_n: int`, `final_candidates_n: int`, `semantic_weight: float`, `redrob_weight: float`, `cache_dir: Path`, `embeddings_cache_dir: Path`, `gemma_cache_dir: Path`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_config.py
import pytest
from config import settings

def test_settings_have_required_fields():
    assert settings.gemini_flash_model
    assert settings.gemini_pro_model
    assert settings.minilm_model
    assert settings.gemma_model
    assert settings.prefilter_top_n == 2500
    assert settings.final_candidates_n == 150
    assert settings.semantic_weight == 0.65
    assert settings.redrob_weight == 0.35
    assert abs(settings.semantic_weight + settings.redrob_weight - 1.0) < 1e-6

def test_cache_dirs_exist():
    assert settings.embeddings_cache_dir.exists()
    assert settings.gemma_cache_dir.exists()
```

- [ ] **Step 2: Run test to verify it fails**

```bash
cd /Users/abhit.pandey/Downloads/Workspace/POCs/jobreranking
pytest tests/test_config.py -v
```
Expected: `ModuleNotFoundError: No module named 'config'`

- [ ] **Step 3: Create project directories and install dependencies**

```bash
mkdir -p pipeline embeddings models data scoring output prompts scripts tests cache/embeddings_cache cache/gemma_cache
touch pipeline/__init__.py embeddings/__init__.py models/__init__.py data/__init__.py scoring/__init__.py output/__init__.py tests/__init__.py
```

Create `requirements.txt`:
```
sentence-transformers==3.4.1
faiss-cpu==1.9.0
transformers==4.47.0
torch==2.5.1
google-generativeai==0.8.3
pydantic==2.10.4
pydantic-settings==2.7.0
ijson==3.3.0
numpy==2.2.1
python-dotenv==1.0.1
pytest==8.3.4
```

```bash
pip install -r requirements.txt
```

- [ ] **Step 4: Create `.env.example`**

```bash
# .env.example
GOOGLE_API_KEY=your_google_api_key_here
GEMINI_FLASH_MODEL=gemini-2.5-flash
GEMINI_PRO_MODEL=gemini-2.5-pro-preview
MINILM_MODEL=sentence-transformers/all-MiniLM-L6-v2
GEMMA_MODEL=google/gemma-3-300M
PREFILTER_TOP_N=2500
FINAL_CANDIDATES_N=150
SEMANTIC_WEIGHT=0.65
REDROB_WEIGHT=0.35
CANDIDATES_FILE=[PUB] India_runs_data_and_ai_challenge/India_runs_data_and_ai_challenge/candidates.json
```

Copy to `.env` and fill in `GOOGLE_API_KEY`.

- [ ] **Step 5: Write `config.py`**

```python
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    google_api_key: str = ""
    gemini_flash_model: str = "gemini-2.5-flash"
    gemini_pro_model: str = "gemini-2.5-pro-preview"
    minilm_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    gemma_model: str = "google/gemma-3-300M"
    prefilter_top_n: int = 2500
    final_candidates_n: int = 150
    semantic_weight: float = 0.65
    redrob_weight: float = 0.35
    candidates_file: str = "[PUB] India_runs_data_and_ai_challenge/India_runs_data_and_ai_challenge/candidates.json"

    @property
    def cache_dir(self) -> Path:
        return Path("cache")

    @property
    def embeddings_cache_dir(self) -> Path:
        p = Path("cache/embeddings_cache")
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def gemma_cache_dir(self) -> Path:
        p = Path("cache/gemma_cache")
        p.mkdir(parents=True, exist_ok=True)
        return p

settings = Settings()
```

- [ ] **Step 6: Write prompt files**

`prompts/ideal_candidate.txt`:
```
You are a senior technical recruiter with 15 years of experience hiring for data and AI roles.

Given the following job description, extract a structured ideal candidate profile.
Return ONLY valid JSON matching this exact schema — no markdown, no explanation:

{
  "required_skills": ["list of must-have technical skills"],
  "preferred_skills": ["list of nice-to-have skills"],
  "experience_requirements": {
    "min_years": <integer>,
    "seniority": "<junior|mid|senior|lead|principal>",
    "domains": ["list of relevant domains e.g. ML, data engineering, NLP"],
    "trajectory_signals": ["list of career growth patterns that indicate strong fit"]
  },
  "red_flags": ["list of signals that indicate poor fit"],
  "soft_signals": {
    "summary_traits": ["personality/work-style traits that indicate fit"],
    "activities_and_awards": ["relevant extracurriculars, open source, publications"],
    "certifications": ["relevant certifications"]
  },
  "dimension_weights": {
    "skills": <float between 0 and 1>,
    "experience": <float between 0 and 1>,
    "soft_signals": <float between 0 and 1>
  }
}

Rules:
- dimension_weights must sum to exactly 1.0
- Be specific — "PyTorch for production model training" not just "PyTorch"
- trajectory_signals describe patterns e.g. "transitioned from data engineering to ML"
- red_flags describe patterns e.g. "only has tutorial-level project experience"

JOB DESCRIPTION:
{{jd_text}}
```

`prompts/final_ranking.txt`:
```
You are a senior technical recruiter making final hiring decisions.

You have been given a pre-scored shortlist of candidates for the following role.
Each candidate has semantic fit scores (skills, experience, soft signals) and platform engagement scores.

Your task: Rank ALL candidates from 1 (best fit) to {{total}} and assign a final score between 0.0 and 1.0.
Scores must be non-increasing (rank 1 has the highest score).

IMPORTANT RULES:
- Only cite facts present in the candidate data. Do not infer or invent achievements.
- A candidate with slightly lower semantic fit but strong engagement and responsiveness
  should rank above a well-matched but disengaged candidate.
- Red flags from the ideal profile should lower rank significantly.
- reasoning must be one sentence, max 20 words, citing only provided data.

Return ONLY a JSON array — no markdown, no explanation:
[
  {
    "candidate_id": "CAND_XXXXXXX",
    "rank": <integer 1 to {{total}}>,
    "score": <float 0.0 to 1.0>,
    "reasoning": "<one sentence max 20 words citing only provided facts>"
  },
  ...
]

IDEAL CANDIDATE PROFILE:
{{ideal_profile_json}}

CANDIDATES TO RANK:
{{candidates_json}}
```

- [ ] **Step 7: Run test to verify it passes**

```bash
pytest tests/test_config.py -v
```
Expected: `2 passed`

- [ ] **Step 8: Commit**

```bash
git init
git add config.py requirements.txt .env.example prompts/ cache/ tests/test_config.py pipeline/__init__.py embeddings/__init__.py models/__init__.py data/__init__.py scoring/__init__.py output/__init__.py tests/__init__.py
git commit -m "feat: project scaffold, config, prompts"
```

---

## Task 2: Pydantic Models

**Files:**
- Create: `models/candidate.py`
- Create: `models/ideal_profile.py`
- Create: `models/scoring.py`
- Test: `tests/test_models.py`

**Interfaces:**
- Produces:
  - `models.candidate.Candidate` — full candidate Pydantic model
  - `models.candidate.RedrobSignals` — nested signals model
  - `models.ideal_profile.IdealProfile` — Stage 2 output model
  - `models.ideal_profile.DimensionWeights` — weights submodel
  - `models.scoring.CandidateScore` — intermediate score after Stage 4
  - `models.scoring.FinalRankedCandidate` — Stage 5 output per candidate

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_models.py
import pytest
from models.candidate import Candidate, RedrobSignals
from models.ideal_profile import IdealProfile, DimensionWeights
from models.scoring import CandidateScore, FinalRankedCandidate

def test_candidate_parses_valid_data():
    raw = {
        "candidate_id": "CAND_0000001",
        "profile": {
            "anonymized_name": "Test User",
            "headline": "ML Engineer",
            "summary": "5 years ML",
            "location": "Mumbai",
            "country": "India",
            "years_of_experience": 5.0,
            "current_title": "ML Engineer",
            "current_company": "Acme",
            "current_company_size": "51-200",
            "current_industry": "Tech"
        },
        "career_history": [{
            "company": "Acme", "title": "ML Engineer",
            "start_date": "2020-01-01", "end_date": None,
            "duration_months": 60, "is_current": True,
            "industry": "Tech", "company_size": "51-200",
            "description": "Built models"
        }],
        "education": [],
        "skills": [{"name": "Python", "proficiency": "expert", "endorsements": 10, "duration_months": 60}],
        "redrob_signals": {
            "profile_completeness_score": 85.0,
            "signup_date": "2025-01-01",
            "last_active_date": "2026-06-01",
            "open_to_work_flag": True,
            "profile_views_received_30d": 10,
            "applications_submitted_30d": 2,
            "recruiter_response_rate": 0.8,
            "avg_response_time_hours": 4.0,
            "skill_assessment_scores": {"Python": 90.0},
            "connection_count": 200,
            "endorsements_received": 50,
            "notice_period_days": 30,
            "expected_salary_range_inr_lpa": {"min": 20.0, "max": 35.0},
            "preferred_work_mode": "hybrid",
            "willing_to_relocate": True,
            "github_activity_score": 75.0,
            "search_appearance_30d": 15,
            "saved_by_recruiters_30d": 3,
            "interview_completion_rate": 1.0,
            "offer_acceptance_rate": 0.8,
            "verified_email": True,
            "verified_phone": True,
            "linkedin_connected": True
        }
    }
    c = Candidate.model_validate(raw)
    assert c.candidate_id == "CAND_0000001"
    assert c.redrob_signals.github_activity_score == 75.0

def test_ideal_profile_weights_sum_to_one():
    w = DimensionWeights(skills=0.4, experience=0.4, soft_signals=0.2)
    assert abs(w.skills + w.experience + w.soft_signals - 1.0) < 1e-6

def test_ideal_profile_weights_invalid_raises():
    with pytest.raises(Exception):
        DimensionWeights(skills=0.5, experience=0.5, soft_signals=0.5)

def test_candidate_score_fields():
    cs = CandidateScore(
        candidate_id="CAND_0000001",
        skills_score=0.8, experience_score=0.7, soft_signals_score=0.6,
        semantic_composite=0.73, redrob_score=0.65, blended_score=0.70,
        is_low_quality=False
    )
    assert cs.blended_score == 0.70

def test_final_ranked_candidate_fields():
    frc = FinalRankedCandidate(
        candidate_id="CAND_0000001", rank=1, score=0.95,
        reasoning="Strong ML background with active GitHub."
    )
    assert frc.rank == 1
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/test_models.py -v
```
Expected: `ModuleNotFoundError: No module named 'models.candidate'`

- [ ] **Step 3: Write `models/candidate.py`**

```python
from datetime import date
from typing import Optional
from pydantic import BaseModel, Field

class CareerEntry(BaseModel):
    company: str
    title: str
    start_date: date
    end_date: Optional[date] = None
    duration_months: int
    is_current: bool
    industry: str
    company_size: str
    description: str

class Education(BaseModel):
    institution: str
    degree: str
    field_of_study: str
    start_year: int
    end_year: int
    grade: Optional[str] = None
    tier: Optional[str] = None

class Skill(BaseModel):
    name: str
    proficiency: str
    endorsements: int
    duration_months: Optional[int] = None

class Certification(BaseModel):
    name: str
    issuer: str
    year: int

class Language(BaseModel):
    language: str
    proficiency: str

class SalaryRange(BaseModel):
    min: float
    max: float

class RedrobSignals(BaseModel):
    profile_completeness_score: float
    signup_date: date
    last_active_date: date
    open_to_work_flag: bool
    profile_views_received_30d: int
    applications_submitted_30d: int
    recruiter_response_rate: float
    avg_response_time_hours: float
    skill_assessment_scores: dict[str, float] = Field(default_factory=dict)
    connection_count: int
    endorsements_received: int
    notice_period_days: int
    expected_salary_range_inr_lpa: SalaryRange
    preferred_work_mode: str
    willing_to_relocate: bool
    github_activity_score: float
    search_appearance_30d: int
    saved_by_recruiters_30d: int
    interview_completion_rate: float
    offer_acceptance_rate: float
    verified_email: bool
    verified_phone: bool
    linkedin_connected: bool

class Profile(BaseModel):
    anonymized_name: str
    headline: str
    summary: str
    location: str
    country: str
    years_of_experience: float
    current_title: str
    current_company: str
    current_company_size: str
    current_industry: str

class Candidate(BaseModel):
    candidate_id: str
    profile: Profile
    career_history: list[CareerEntry]
    education: list[Education] = Field(default_factory=list)
    skills: list[Skill] = Field(default_factory=list)
    certifications: list[Certification] = Field(default_factory=list)
    languages: list[Language] = Field(default_factory=list)
    redrob_signals: RedrobSignals
```

- [ ] **Step 4: Write `models/ideal_profile.py`**

```python
from pydantic import BaseModel, model_validator

class ExperienceRequirements(BaseModel):
    min_years: int
    seniority: str
    domains: list[str]
    trajectory_signals: list[str]

class SoftSignals(BaseModel):
    summary_traits: list[str]
    activities_and_awards: list[str]
    certifications: list[str]

class DimensionWeights(BaseModel):
    skills: float
    experience: float
    soft_signals: float

    @model_validator(mode="after")
    def weights_sum_to_one(self) -> "DimensionWeights":
        total = self.skills + self.experience + self.soft_signals
        if abs(total - 1.0) > 0.05:
            raise ValueError(f"dimension_weights must sum to 1.0, got {total:.3f}")
        return self

class IdealProfile(BaseModel):
    required_skills: list[str]
    preferred_skills: list[str]
    experience_requirements: ExperienceRequirements
    red_flags: list[str]
    soft_signals: SoftSignals
    dimension_weights: DimensionWeights
```

- [ ] **Step 5: Write `models/scoring.py`**

```python
from pydantic import BaseModel

class CandidateScore(BaseModel):
    candidate_id: str
    skills_score: float
    experience_score: float
    soft_signals_score: float
    semantic_composite: float
    redrob_score: float
    blended_score: float
    is_low_quality: bool = False

class FinalRankedCandidate(BaseModel):
    candidate_id: str
    rank: int
    score: float
    reasoning: str
```

- [ ] **Step 6: Run tests to verify they pass**

```bash
pytest tests/test_models.py -v
```
Expected: `5 passed`

- [ ] **Step 7: Commit**

```bash
git add models/
git add tests/test_models.py
git commit -m "feat: pydantic models for candidate, ideal profile, scoring"
```

---

## Task 3: Data Loader + Candidate Text Builder

**Files:**
- Create: `data/loader.py`
- Create: `data/candidate_texts.py`
- Test: `tests/test_data.py`

**Interfaces:**
- Consumes: `models.candidate.Candidate`
- Produces:
  - `data.loader.stream_candidates(path: str) -> Iterator[Candidate]`
  - `data.candidate_texts.build_minilm_text(candidate: Candidate) -> str`
  - `data.candidate_texts.build_skills_text(candidate: Candidate) -> str`
  - `data.candidate_texts.build_experience_text(candidate: Candidate) -> str`
  - `data.candidate_texts.build_soft_signals_text(candidate: Candidate) -> str`

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_data.py
import json, pytest
from models.candidate import Candidate
from data.loader import stream_candidates
from data.candidate_texts import (
    build_minilm_text, build_skills_text,
    build_experience_text, build_soft_signals_text
)

SAMPLE_PATH = "[PUB] India_runs_data_and_ai_challenge/India_runs_data_and_ai_challenge/sample_candidates.json"

def test_stream_candidates_yields_candidates():
    count = 0
    for c in stream_candidates(SAMPLE_PATH):
        assert isinstance(c, Candidate)
        assert c.candidate_id.startswith("CAND_")
        count += 1
    assert count > 0

def _sample_candidate():
    with open(SAMPLE_PATH) as f:
        lines = [l.strip() for l in f if l.strip()]
    return Candidate.model_validate(json.loads(lines[0]))

def test_build_minilm_text_contains_headline():
    c = _sample_candidate()
    text = build_minilm_text(c)
    assert c.profile.headline in text

def test_build_skills_text_contains_skill_names():
    c = _sample_candidate()
    text = build_skills_text(c)
    for skill in c.skills[:3]:
        assert skill.name in text

def test_build_experience_text_contains_titles():
    c = _sample_candidate()
    text = build_experience_text(c)
    assert c.career_history[0].title in text

def test_build_soft_signals_text_contains_summary():
    c = _sample_candidate()
    text = build_soft_signals_text(c)
    assert c.profile.summary[:50] in text
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/test_data.py -v
```
Expected: `ModuleNotFoundError: No module named 'data.loader'`

- [ ] **Step 3: Write `data/loader.py`**

```python
import json
from typing import Iterator
from models.candidate import Candidate

def stream_candidates(path: str) -> Iterator[Candidate]:
    """Stream candidates from NDJSON file one at a time — never loads all into RAM."""
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                yield Candidate.model_validate(json.loads(line))
            except Exception:
                continue  # skip malformed lines silently
```

- [ ] **Step 4: Write `data/candidate_texts.py`**

```python
from models.candidate import Candidate

def build_minilm_text(candidate: Candidate) -> str:
    """Broad text for Stage 1 pre-filter — headline + summary + top 3 roles + skill names."""
    parts = [candidate.profile.headline, candidate.profile.summary]
    for entry in candidate.career_history[:3]:
        parts.append(entry.description)
    skill_names = " ".join(s.name for s in candidate.skills)
    parts.append(skill_names)
    return " | ".join(p for p in parts if p)

def build_skills_text(candidate: Candidate) -> str:
    """Skills dimension text for Stage 3 Gemma embedding."""
    skill_parts = []
    for s in candidate.skills:
        months = f"{s.duration_months}mo" if s.duration_months else ""
        skill_parts.append(f"{s.name} ({s.proficiency}) {months}".strip())
    assessment_keys = list(candidate.redrob_signals.skill_assessment_scores.keys())
    if assessment_keys:
        skill_parts.append("Assessed: " + ", ".join(assessment_keys))
    return "; ".join(skill_parts)

def build_experience_text(candidate: Candidate) -> str:
    """Experience dimension text for Stage 3 Gemma embedding."""
    parts = [
        f"{candidate.profile.years_of_experience} years experience",
        f"Current: {candidate.profile.current_title} at {candidate.profile.current_company}",
    ]
    for entry in candidate.career_history:
        parts.append(f"{entry.title} at {entry.company} ({entry.industry}): {entry.description}")
    return " | ".join(parts)

def build_soft_signals_text(candidate: Candidate) -> str:
    """Soft signals dimension text for Stage 3 Gemma embedding."""
    parts = [candidate.profile.summary]
    if candidate.certifications:
        certs = ", ".join(c.name for c in candidate.certifications)
        parts.append(f"Certifications: {certs}")
    if candidate.languages:
        langs = ", ".join(f"{l.language} ({l.proficiency})" for l in candidate.languages)
        parts.append(f"Languages: {langs}")
    if candidate.education:
        edu_parts = []
        for e in candidate.education:
            tier = f" [{e.tier}]" if e.tier else ""
            edu_parts.append(f"{e.degree} in {e.field_of_study} from {e.institution}{tier}")
        parts.append("Education: " + "; ".join(edu_parts))
    return " | ".join(p for p in parts if p)
```

- [ ] **Step 5: Run tests to verify they pass**

```bash
pytest tests/test_data.py -v
```
Expected: `5 passed`

- [ ] **Step 6: Commit**

```bash
git add data/ tests/test_data.py
git commit -m "feat: streaming NDJSON loader and candidate text builders"
```

---

## Task 4: Embedding Encoders + FAISS Index

**Files:**
- Create: `embeddings/minilm_encoder.py`
- Create: `embeddings/gemma_encoder.py`
- Create: `embeddings/faiss_index.py`
- Test: `tests/test_embeddings.py`

**Interfaces:**
- Produces:
  - `embeddings.minilm_encoder.MiniLMEncoder.encode(texts: list[str]) -> np.ndarray` — shape `(N, 384)`
  - `embeddings.gemma_encoder.GemmaEncoder.encode(texts: list[str]) -> np.ndarray` — shape `(N, D)` where D is Gemma 300M hidden size
  - `embeddings.faiss_index.FaissIndex.build(embeddings: np.ndarray, ids: list[str]) -> None`
  - `embeddings.faiss_index.FaissIndex.save(path: str) -> None`
  - `embeddings.faiss_index.FaissIndex.load(path: str) -> FaissIndex`
  - `embeddings.faiss_index.FaissIndex.query(query_embedding: np.ndarray, top_k: int) -> list[str]` — returns candidate_ids

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_embeddings.py
import numpy as np
import pytest, tempfile, os
from embeddings.minilm_encoder import MiniLMEncoder
from embeddings.gemma_encoder import GemmaEncoder
from embeddings.faiss_index import FaissIndex

def test_minilm_encode_returns_correct_shape():
    enc = MiniLMEncoder()
    result = enc.encode(["hello world", "machine learning engineer"])
    assert result.shape == (2, 384)
    assert result.dtype == np.float32

def test_minilm_encode_single_string():
    enc = MiniLMEncoder()
    result = enc.encode(["test"])
    assert result.shape == (1, 384)

def test_gemma_encode_returns_ndarray():
    enc = GemmaEncoder()
    result = enc.encode(["Python expert 60 months; PyTorch advanced"])
    assert isinstance(result, np.ndarray)
    assert result.shape[0] == 1
    assert result.dtype == np.float32

def test_gemma_encode_is_normalized():
    enc = GemmaEncoder()
    result = enc.encode(["test text"])
    norm = np.linalg.norm(result[0])
    assert abs(norm - 1.0) < 1e-5

def test_faiss_index_build_query_save_load():
    enc = MiniLMEncoder()
    texts = ["machine learning engineer", "accountant finance", "data scientist python"]
    ids = ["CAND_0000001", "CAND_0000002", "CAND_0000003"]
    embs = enc.encode(texts)

    idx = FaissIndex()
    idx.build(embs, ids)

    query = enc.encode(["deep learning researcher"])
    results = idx.query(query[0], top_k=2)
    assert len(results) == 2
    assert "CAND_0000001" in results  # ML engineer should be top result

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "test.index")
        idx.save(path)
        loaded = FaissIndex.load(path)
        results2 = loaded.query(query[0], top_k=2)
        assert results == results2
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/test_embeddings.py -v
```
Expected: `ModuleNotFoundError: No module named 'embeddings.minilm_encoder'`

- [ ] **Step 3: Write `embeddings/minilm_encoder.py`**

```python
import numpy as np
from sentence_transformers import SentenceTransformer
from config import settings

class MiniLMEncoder:
    def __init__(self):
        self._model = SentenceTransformer(settings.minilm_model)

    def encode(self, texts: list[str], batch_size: int = 256) -> np.ndarray:
        embeddings = self._model.encode(
            texts,
            batch_size=batch_size,
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        return embeddings.astype(np.float32)
```

- [ ] **Step 4: Write `embeddings/gemma_encoder.py`**

```python
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModel
from config import settings

class GemmaEncoder:
    def __init__(self):
        self._tokenizer = AutoTokenizer.from_pretrained(settings.gemma_model)
        self._model = AutoModel.from_pretrained(settings.gemma_model)
        self._model.eval()

    def encode(self, texts: list[str], batch_size: int = 32) -> np.ndarray:
        all_embeddings = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            inputs = self._tokenizer(
                batch, padding=True, truncation=True,
                max_length=512, return_tensors="pt"
            )
            with torch.no_grad():
                outputs = self._model(**inputs)
            # Mean pool over non-padding tokens
            attention_mask = inputs["attention_mask"]
            token_embeddings = outputs.last_hidden_state
            mask_expanded = attention_mask.unsqueeze(-1).float()
            summed = (token_embeddings * mask_expanded).sum(dim=1)
            counts = mask_expanded.sum(dim=1).clamp(min=1e-9)
            mean_pooled = (summed / counts).cpu().numpy().astype(np.float32)
            # L2 normalize
            norms = np.linalg.norm(mean_pooled, axis=1, keepdims=True).clip(min=1e-9)
            all_embeddings.append(mean_pooled / norms)
        return np.vstack(all_embeddings)
```

- [ ] **Step 5: Write `embeddings/faiss_index.py`**

```python
import pickle
import numpy as np
import faiss

class FaissIndex:
    def __init__(self):
        self._index: faiss.Index | None = None
        self._ids: list[str] = []

    def build(self, embeddings: np.ndarray, ids: list[str]) -> None:
        dim = embeddings.shape[1]
        self._index = faiss.IndexFlatIP(dim)  # inner product = cosine on normalized vecs
        self._index.add(embeddings)
        self._ids = list(ids)

    def query(self, query_embedding: np.ndarray, top_k: int) -> list[str]:
        if self._index is None:
            raise RuntimeError("Index not built. Call build() or load() first.")
        q = query_embedding.reshape(1, -1).astype(np.float32)
        _, indices = self._index.search(q, top_k)
        return [self._ids[i] for i in indices[0] if i < len(self._ids)]

    def save(self, path: str) -> None:
        faiss.write_index(self._index, path + ".faiss")
        with open(path + ".ids", "wb") as f:
            pickle.dump(self._ids, f)

    @classmethod
    def load(cls, path: str) -> "FaissIndex":
        obj = cls()
        obj._index = faiss.read_index(path + ".faiss")
        with open(path + ".ids", "rb") as f:
            obj._ids = pickle.load(f)
        return obj
```

- [ ] **Step 6: Run tests to verify they pass**

```bash
pytest tests/test_embeddings.py -v
```
Expected: `5 passed`

- [ ] **Step 7: Commit**

```bash
git add embeddings/ tests/test_embeddings.py
git commit -m "feat: MiniLM encoder, Gemma 300M encoder, FAISS index"
```

---

## Task 5: Redrob Signal Scorer + Composite Scorer

**Files:**
- Create: `scoring/redrob_signals.py`
- Create: `scoring/composite.py`
- Test: `tests/test_scoring.py`

**Interfaces:**
- Consumes: `models.candidate.RedrobSignals`, `models.ideal_profile.DimensionWeights`
- Produces:
  - `scoring.redrob_signals.score_redrob(signals: RedrobSignals) -> dict[str, float]` — keys: `engagement`, `responsiveness`, `credibility`, `market_signal`, `technical_signal`, `logistics`, `redrob_composite`
  - `scoring.composite.compute_semantic_composite(skills_score: float, experience_score: float, soft_score: float, weights: DimensionWeights) -> float`

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_scoring.py
import pytest
from datetime import date
from models.candidate import RedrobSignals, SalaryRange
from models.ideal_profile import DimensionWeights
from scoring.redrob_signals import score_redrob
from scoring.composite import compute_semantic_composite

def _make_signals(**overrides) -> RedrobSignals:
    base = {
        "profile_completeness_score": 85.0,
        "signup_date": date(2025, 1, 1),
        "last_active_date": date(2026, 6, 1),
        "open_to_work_flag": True,
        "profile_views_received_30d": 10,
        "applications_submitted_30d": 3,
        "recruiter_response_rate": 0.8,
        "avg_response_time_hours": 4.0,
        "skill_assessment_scores": {"Python": 90.0},
        "connection_count": 200,
        "endorsements_received": 50,
        "notice_period_days": 30,
        "expected_salary_range_inr_lpa": SalaryRange(min=20.0, max=35.0),
        "preferred_work_mode": "hybrid",
        "willing_to_relocate": True,
        "github_activity_score": 75.0,
        "search_appearance_30d": 15,
        "saved_by_recruiters_30d": 3,
        "interview_completion_rate": 1.0,
        "offer_acceptance_rate": 0.8,
        "verified_email": True,
        "verified_phone": True,
        "linkedin_connected": True,
    }
    base.update(overrides)
    return RedrobSignals(**base)

def test_score_redrob_returns_all_keys():
    signals = _make_signals()
    result = score_redrob(signals)
    for key in ["engagement", "responsiveness", "credibility", "market_signal", "technical_signal", "logistics", "redrob_composite"]:
        assert key in result
        assert 0.0 <= result[key] <= 1.0

def test_github_minus_one_treated_as_zero():
    signals_no_github = _make_signals(github_activity_score=-1.0)
    signals_with_github = _make_signals(github_activity_score=0.0)
    r1 = score_redrob(signals_no_github)
    r2 = score_redrob(signals_with_github)
    assert r1["technical_signal"] == r2["technical_signal"]

def test_offer_acceptance_minus_one_treated_as_neutral():
    # offer_acceptance_rate=-1 should not heavily penalize responsiveness
    signals = _make_signals(offer_acceptance_rate=-1.0, interview_completion_rate=1.0, recruiter_response_rate=0.9)
    result = score_redrob(signals)
    assert result["responsiveness"] > 0.5

def test_compute_semantic_composite_weighted():
    weights = DimensionWeights(skills=0.4, experience=0.4, soft_signals=0.2)
    score = compute_semantic_composite(0.9, 0.8, 0.6, weights)
    expected = 0.4 * 0.9 + 0.4 * 0.8 + 0.2 * 0.6
    assert abs(score - expected) < 1e-6

def test_compute_semantic_composite_clamped():
    weights = DimensionWeights(skills=0.4, experience=0.4, soft_signals=0.2)
    score = compute_semantic_composite(1.1, 1.1, 1.1, weights)
    assert score <= 1.0
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/test_scoring.py -v
```
Expected: `ModuleNotFoundError: No module named 'scoring.redrob_signals'`

- [ ] **Step 3: Write `scoring/redrob_signals.py`**

```python
import math
from datetime import date
from models.candidate import RedrobSignals

def _recency_score(last_active: date) -> float:
    days_ago = (date.today() - last_active).days
    if days_ago <= 7:
        return 1.0
    if days_ago <= 30:
        return 0.8
    if days_ago <= 90:
        return 0.5
    if days_ago <= 180:
        return 0.2
    return 0.0

def _log_normalize(value: float, scale: float = 10.0) -> float:
    return min(1.0, math.log1p(value) / math.log1p(scale))

def score_redrob(signals: RedrobSignals) -> dict[str, float]:
    # Engagement
    open_score = 1.0 if signals.open_to_work_flag else 0.3
    recency = _recency_score(signals.last_active_date)
    activity = min(1.0, signals.applications_submitted_30d / 5.0)
    engagement = 0.4 * open_score + 0.4 * recency + 0.2 * activity

    # Responsiveness — offer_acceptance_rate=-1 → 0.5 neutral
    oar = signals.offer_acceptance_rate if signals.offer_acceptance_rate >= 0 else 0.5
    response_time_score = max(0.0, 1.0 - signals.avg_response_time_hours / 168.0)
    responsiveness = (
        0.4 * signals.recruiter_response_rate
        + 0.3 * response_time_score
        + 0.3 * signals.interview_completion_rate
    )

    # Credibility
    verification_score = (
        (1.0 if signals.verified_email else 0.0)
        + (1.0 if signals.verified_phone else 0.0)
        + (1.0 if signals.linkedin_connected else 0.0)
    ) / 3.0
    completeness_norm = signals.profile_completeness_score / 100.0
    credibility = 0.5 * verification_score + 0.5 * completeness_norm

    # Market signal
    saved_norm = _log_normalize(signals.saved_by_recruiters_30d, scale=10.0)
    search_norm = _log_normalize(signals.search_appearance_30d, scale=50.0)
    market_signal = 0.6 * saved_norm + 0.4 * search_norm

    # Technical signal — github_activity_score=-1 → 0
    github = max(0.0, signals.github_activity_score) / 100.0
    assessment_avg = (
        sum(signals.skill_assessment_scores.values()) / len(signals.skill_assessment_scores)
        if signals.skill_assessment_scores else 0.0
    ) / 100.0
    technical_signal = 0.5 * github + 0.5 * assessment_avg

    # Logistics
    notice_score = 1.0 if signals.notice_period_days <= 30 else (
        0.7 if signals.notice_period_days <= 60 else (
        0.4 if signals.notice_period_days <= 90 else 0.1
    ))
    relocate_bonus = 0.2 if signals.willing_to_relocate else 0.0
    logistics = min(1.0, notice_score * 0.8 + relocate_bonus)

    redrob_composite = (
        0.25 * engagement
        + 0.25 * responsiveness
        + 0.20 * credibility
        + 0.10 * market_signal
        + 0.10 * technical_signal
        + 0.10 * logistics
    )

    return {
        "engagement": round(engagement, 4),
        "responsiveness": round(responsiveness, 4),
        "credibility": round(credibility, 4),
        "market_signal": round(market_signal, 4),
        "technical_signal": round(technical_signal, 4),
        "logistics": round(logistics, 4),
        "redrob_composite": round(redrob_composite, 4),
    }
```

- [ ] **Step 4: Write `scoring/composite.py`**

```python
from models.ideal_profile import DimensionWeights

def compute_semantic_composite(
    skills_score: float,
    experience_score: float,
    soft_score: float,
    weights: DimensionWeights,
) -> float:
    raw = (
        weights.skills * skills_score
        + weights.experience * experience_score
        + weights.soft_signals * soft_score
    )
    return round(min(1.0, max(0.0, raw)), 6)
```

- [ ] **Step 5: Run tests to verify they pass**

```bash
pytest tests/test_scoring.py -v
```
Expected: `5 passed`

- [ ] **Step 6: Commit**

```bash
git add scoring/ tests/test_scoring.py
git commit -m "feat: redrob signal scorer and semantic composite scorer"
```

---

## Task 6: Offline Precompute Script

**Files:**
- Create: `scripts/precompute_embeddings.py`
- Test: manual smoke test (see step 6)

**Interfaces:**
- Consumes: `data.loader.stream_candidates`, `data.candidate_texts.*`, `embeddings.minilm_encoder.MiniLMEncoder`, `embeddings.gemma_encoder.GemmaEncoder`, `embeddings.faiss_index.FaissIndex`
- Produces:
  - `cache/embeddings_cache/minilm.index.faiss` + `.ids` — FAISS index for all 100k candidates
  - `cache/gemma_cache/skills.npy`, `cache/gemma_cache/experience.npy`, `cache/gemma_cache/soft_signals.npy` — NOT precomputed for all 100k; computed only for top-2500 at Stage 3 runtime (see note below)
  - `cache/embeddings_cache/candidate_ids.txt` — ordered list of all candidate IDs matching MiniLM index rows

**Note:** Only MiniLM embeddings for all 100k are precomputed here. Gemma embeddings are computed at Stage 3 runtime for the top-2500 only (and cached there). This keeps precompute time reasonable.

- [ ] **Step 1: Write `scripts/precompute_embeddings.py`**

```python
#!/usr/bin/env python3
"""
One-time offline script: embed all 100k candidates with MiniLM → build FAISS index.
Run once before the main pipeline. Takes ~30-60 min on CPU.

Usage:
    python scripts/precompute_embeddings.py --candidates <path_to_candidates.json>
"""
import argparse
import numpy as np
from pathlib import Path
from tqdm import tqdm

from config import settings
from data.loader import stream_candidates
from data.candidate_texts import build_minilm_text
from embeddings.minilm_encoder import MiniLMEncoder
from embeddings.faiss_index import FaissIndex

BATCH_SIZE = 512

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidates", default=settings.candidates_file)
    args = parser.parse_args()

    encoder = MiniLMEncoder()
    index = FaissIndex()

    all_embeddings = []
    all_ids = []
    batch_texts = []
    batch_ids = []

    print(f"Streaming candidates from {args.candidates}...")
    for candidate in tqdm(stream_candidates(args.candidates)):
        text = build_minilm_text(candidate)
        batch_texts.append(text)
        batch_ids.append(candidate.candidate_id)

        if len(batch_texts) >= BATCH_SIZE:
            embs = encoder.encode(batch_texts)
            all_embeddings.append(embs)
            all_ids.extend(batch_ids)
            batch_texts, batch_ids = [], []

    if batch_texts:
        embs = encoder.encode(batch_texts)
        all_embeddings.append(embs)
        all_ids.extend(batch_ids)

    print(f"Building FAISS index for {len(all_ids)} candidates...")
    all_embs = np.vstack(all_embeddings)
    index.build(all_embs, all_ids)

    index_path = str(settings.embeddings_cache_dir / "minilm.index")
    index.save(index_path)

    ids_path = settings.embeddings_cache_dir / "candidate_ids.txt"
    ids_path.write_text("\n".join(all_ids))

    print(f"Done. Index saved to {index_path}.faiss / .ids")
    print(f"Candidate IDs saved to {ids_path}")

if __name__ == "__main__":
    main()
```

- [ ] **Step 2: Run smoke test on sample candidates**

```bash
python scripts/precompute_embeddings.py --candidates "[PUB] India_runs_data_and_ai_challenge/India_runs_data_and_ai_challenge/sample_candidates.json"
```
Expected output:
```
Streaming candidates from ...
Building FAISS index for 5 candidates...
Done. Index saved to cache/embeddings_cache/minilm.index.faiss / .ids
```

Check files exist:
```bash
ls cache/embeddings_cache/
```
Expected: `minilm.index.faiss  minilm.index.ids  candidate_ids.txt`

- [ ] **Step 3: Commit**

```bash
git add scripts/precompute_embeddings.py
git commit -m "feat: offline precompute script for MiniLM FAISS index"
```

---

## Task 7: Pipeline Stage 1 — miniLM Pre-filter

**Files:**
- Create: `pipeline/stage1_prefilter.py`
- Test: `tests/test_stage1.py`

**Interfaces:**
- Consumes: `embeddings.minilm_encoder.MiniLMEncoder`, `embeddings.faiss_index.FaissIndex`, `config.settings`
- Produces: `pipeline.stage1_prefilter.run_stage1(jd_text: str) -> list[str]` — ordered list of top-N `candidate_id`s

- [ ] **Step 1: Write the failing test**

```python
# tests/test_stage1.py
import pytest
from unittest.mock import patch
import numpy as np
from pipeline.stage1_prefilter import run_stage1

JD_TEXT = "We are hiring a Senior ML Engineer with PyTorch, NLP, and production ML system experience."

def test_run_stage1_returns_list_of_candidate_ids(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    # Build a tiny index for the test
    from embeddings.minilm_encoder import MiniLMEncoder
    from embeddings.faiss_index import FaissIndex
    from pathlib import Path
    import os

    cache_dir = tmp_path / "cache" / "embeddings_cache"
    cache_dir.mkdir(parents=True)

    enc = MiniLMEncoder()
    texts = ["ML engineer PyTorch NLP", "accountant finance", "data scientist python"]
    ids = ["CAND_0000001", "CAND_0000002", "CAND_0000003"]
    embs = enc.encode(texts)

    idx = FaissIndex()
    idx.build(embs, ids)
    idx.save(str(cache_dir / "minilm.index"))

    from config import settings
    monkeypatch.setattr(settings, "embeddings_cache_dir", cache_dir)
    monkeypatch.setattr(settings, "prefilter_top_n", 2)

    results = run_stage1(JD_TEXT)
    assert isinstance(results, list)
    assert len(results) == 2
    assert all(cid.startswith("CAND_") for cid in results)
    assert "CAND_0000001" in results  # ML engineer should be top result
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/test_stage1.py -v
```
Expected: `ModuleNotFoundError: No module named 'pipeline.stage1_prefilter'`

- [ ] **Step 3: Write `pipeline/stage1_prefilter.py`**

```python
from config import settings
from embeddings.minilm_encoder import MiniLMEncoder
from embeddings.faiss_index import FaissIndex

def run_stage1(jd_text: str) -> list[str]:
    """Embed JD with MiniLM, query FAISS index, return top-N candidate_ids."""
    encoder = MiniLMEncoder()
    index_path = str(settings.embeddings_cache_dir / "minilm.index")
    index = FaissIndex.load(index_path)

    jd_embedding = encoder.encode([jd_text])[0]
    top_ids = index.query(jd_embedding, top_k=settings.prefilter_top_n)
    return top_ids
```

- [ ] **Step 4: Run test to verify it passes**

```bash
pytest tests/test_stage1.py -v
```
Expected: `1 passed`

- [ ] **Step 5: Commit**

```bash
git add pipeline/stage1_prefilter.py tests/test_stage1.py
git commit -m "feat: stage 1 miniLM broad pre-filter"
```

---

## Task 8: Pipeline Stage 2 — Gemini Flash Ideal Profile

**Files:**
- Create: `pipeline/stage2_ideal_profile.py`
- Test: `tests/test_stage2.py`

**Interfaces:**
- Consumes: `models.ideal_profile.IdealProfile`, `config.settings`, `prompts/ideal_candidate.txt`
- Produces: `pipeline.stage2_ideal_profile.run_stage2(jd_text: str) -> IdealProfile`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_stage2.py
import json, pytest
from unittest.mock import patch, MagicMock
from models.ideal_profile import IdealProfile
from pipeline.stage2_ideal_profile import run_stage2

SAMPLE_JD = "Hiring a Senior ML Engineer. Must have: Python, PyTorch, 5+ years ML. Nice to have: MLflow, Kubernetes."

MOCK_LLM_RESPONSE = json.dumps({
    "required_skills": ["Python", "PyTorch"],
    "preferred_skills": ["MLflow", "Kubernetes"],
    "experience_requirements": {
        "min_years": 5,
        "seniority": "senior",
        "domains": ["Machine Learning", "Deep Learning"],
        "trajectory_signals": ["transitioned from SWE to ML", "led ML projects"]
    },
    "red_flags": ["only tutorial-level projects", "no production ML experience"],
    "soft_signals": {
        "summary_traits": ["self-directed learner", "collaborates with product teams"],
        "activities_and_awards": ["open source contributions", "Kaggle competitions"],
        "certifications": ["Google ML Professional"]
    },
    "dimension_weights": {"skills": 0.45, "experience": 0.40, "soft_signals": 0.15}
})

def test_run_stage2_returns_ideal_profile(tmp_path, monkeypatch):
    mock_model = MagicMock()
    mock_response = MagicMock()
    mock_response.text = MOCK_LLM_RESPONSE
    mock_model.generate_content.return_value = mock_response

    monkeypatch.setattr("pipeline.stage2_ideal_profile._get_model", lambda: mock_model)
    monkeypatch.setattr("pipeline.stage2_ideal_profile.CACHE_PATH",
                        str(tmp_path / "ideal_profile_cache.json"))

    profile = run_stage2(SAMPLE_JD)
    assert isinstance(profile, IdealProfile)
    assert "Python" in profile.required_skills
    assert profile.dimension_weights.skills == 0.45

def test_run_stage2_uses_cache(tmp_path, monkeypatch):
    import json
    cache_path = str(tmp_path / "ideal_profile_cache.json")
    cached = {"jd_hash": "abc123", "profile": json.loads(MOCK_LLM_RESPONSE)}

    with open(cache_path, "w") as f:
        json.dump(cached, f)

    call_count = {"n": 0}
    def mock_get_model():
        m = MagicMock()
        def side_effect(*a, **kw):
            call_count["n"] += 1
            r = MagicMock(); r.text = MOCK_LLM_RESPONSE; return r
        m.generate_content.side_effect = side_effect
        return m

    monkeypatch.setattr("pipeline.stage2_ideal_profile._get_model", mock_get_model)
    monkeypatch.setattr("pipeline.stage2_ideal_profile.CACHE_PATH", cache_path)
    monkeypatch.setattr("pipeline.stage2_ideal_profile._jd_hash", lambda t: "abc123")

    run_stage2(SAMPLE_JD)
    assert call_count["n"] == 0  # LLM was NOT called — used cache
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/test_stage2.py -v
```
Expected: `ModuleNotFoundError: No module named 'pipeline.stage2_ideal_profile'`

- [ ] **Step 3: Write `pipeline/stage2_ideal_profile.py`**

```python
import hashlib, json
from pathlib import Path
import google.generativeai as genai
from config import settings
from models.ideal_profile import IdealProfile

CACHE_PATH = "cache/ideal_profile_cache.json"
_PROMPT_PATH = Path("prompts/ideal_candidate.txt")

def _jd_hash(jd_text: str) -> str:
    return hashlib.md5(jd_text.encode()).hexdigest()

def _get_model():
    genai.configure(api_key=settings.google_api_key)
    return genai.GenerativeModel(settings.gemini_flash_model)

def _load_prompt(jd_text: str) -> str:
    template = _PROMPT_PATH.read_text(encoding="utf-8")
    return template.replace("{{jd_text}}", jd_text)

def _call_llm(jd_text: str) -> IdealProfile:
    model = _get_model()
    prompt = _load_prompt(jd_text)
    response = model.generate_content(prompt)
    raw = response.text.strip()
    # Strip markdown code fences if present
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    return IdealProfile.model_validate(json.loads(raw))

def run_stage2(jd_text: str) -> IdealProfile:
    """Return IdealProfile from cache if JD unchanged, otherwise call Gemini Flash."""
    jd_key = _jd_hash(jd_text)
    cache_path = Path(CACHE_PATH)

    if cache_path.exists():
        cached = json.loads(cache_path.read_text(encoding="utf-8"))
        if cached.get("jd_hash") == jd_key:
            return IdealProfile.model_validate(cached["profile"])

    profile = _call_llm(jd_text)

    # Retry once if validation failed (shouldn't reach here — model_validate raises above)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(
        json.dumps({"jd_hash": jd_key, "profile": profile.model_dump()}, indent=2),
        encoding="utf-8",
    )
    return profile
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
pytest tests/test_stage2.py -v
```
Expected: `2 passed`

- [ ] **Step 5: Commit**

```bash
git add pipeline/stage2_ideal_profile.py tests/test_stage2.py
git commit -m "feat: stage 2 Gemini Flash ideal candidate profile generator"
```

---

## Task 9: Pipeline Stage 3 — Gemma Multi-dimensional Re-scoring

**Files:**
- Create: `pipeline/stage3_reranker.py`
- Test: `tests/test_stage3.py`

**Interfaces:**
- Consumes: `models.ideal_profile.IdealProfile`, `models.candidate.Candidate`, `embeddings.gemma_encoder.GemmaEncoder`, `scoring.composite.compute_semantic_composite`, `data.candidate_texts.*`
- Produces: `pipeline.stage3_reranker.run_stage3(ideal_profile: IdealProfile, top_candidate_ids: list[str], all_candidates: dict[str, Candidate]) -> list[tuple[str, float, float, float, float]]`
  — list of `(candidate_id, skills_score, experience_score, soft_score, semantic_composite)` sorted descending by `semantic_composite`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_stage3.py
import json, pytest
from models.ideal_profile import IdealProfile, DimensionWeights, ExperienceRequirements, SoftSignals
from models.candidate import Candidate
from pipeline.stage3_reranker import run_stage3

SAMPLE_PATH = "[PUB] India_runs_data_and_ai_challenge/India_runs_data_and_ai_challenge/sample_candidates.json"

def _load_sample_candidates() -> dict:
    candidates = {}
    with open(SAMPLE_PATH) as f:
        for line in f:
            line = line.strip()
            if line:
                c = Candidate.model_validate(json.loads(line))
                candidates[c.candidate_id] = c
    return candidates

def _make_ideal_profile() -> IdealProfile:
    return IdealProfile(
        required_skills=["Python", "Machine Learning", "PyTorch"],
        preferred_skills=["MLflow", "Kubernetes"],
        experience_requirements=ExperienceRequirements(
            min_years=3, seniority="senior",
            domains=["ML", "Data Science"],
            trajectory_signals=["grew from SWE to ML lead"]
        ),
        red_flags=["no production experience"],
        soft_signals=SoftSignals(
            summary_traits=["self-starter"],
            activities_and_awards=["Kaggle"],
            certifications=["Google ML"]
        ),
        dimension_weights=DimensionWeights(skills=0.4, experience=0.4, soft_signals=0.2)
    )

def test_run_stage3_returns_sorted_scores():
    candidates = _load_sample_candidates()
    ideal = _make_ideal_profile()
    top_ids = list(candidates.keys())[:3]

    results = run_stage3(ideal, top_ids, candidates)

    assert len(results) == 3
    for cid, sk, ex, soft, comp in results:
        assert cid.startswith("CAND_")
        assert 0.0 <= sk <= 1.0
        assert 0.0 <= ex <= 1.0
        assert 0.0 <= soft <= 1.0
        assert 0.0 <= comp <= 1.0

    # Verify sorted descending by composite
    composites = [comp for _, _, _, _, comp in results]
    assert composites == sorted(composites, reverse=True)
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/test_stage3.py -v
```
Expected: `ModuleNotFoundError: No module named 'pipeline.stage3_reranker'`

- [ ] **Step 3: Write `pipeline/stage3_reranker.py`**

```python
import numpy as np
from models.ideal_profile import IdealProfile
from models.candidate import Candidate
from embeddings.gemma_encoder import GemmaEncoder
from scoring.composite import compute_semantic_composite
from data.candidate_texts import build_skills_text, build_experience_text, build_soft_signals_text

def _build_query_texts(ideal: IdealProfile) -> tuple[str, str, str]:
    skills_query = ", ".join(ideal.required_skills + ideal.preferred_skills)
    exp_req = ideal.experience_requirements
    experience_query = (
        f"{exp_req.seniority} level, {exp_req.min_years}+ years, "
        f"domains: {', '.join(exp_req.domains)}. "
        f"Trajectory: {'; '.join(exp_req.trajectory_signals)}"
    )
    soft = ideal.soft_signals
    soft_query = (
        f"Traits: {', '.join(soft.summary_traits)}. "
        f"Activities: {', '.join(soft.activities_and_awards)}. "
        f"Certs: {', '.join(soft.certifications)}"
    )
    return skills_query, experience_query, soft_query

def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    # Both are already L2-normalized by GemmaEncoder
    return float(np.dot(a, b))

def run_stage3(
    ideal_profile: IdealProfile,
    top_candidate_ids: list[str],
    all_candidates: dict[str, Candidate],
) -> list[tuple[str, float, float, float, float]]:
    """
    Returns list of (candidate_id, skills_score, experience_score, soft_score, semantic_composite)
    sorted descending by semantic_composite.
    """
    encoder = GemmaEncoder()
    skills_q, exp_q, soft_q = _build_query_texts(ideal_profile)

    query_embs = encoder.encode([skills_q, exp_q, soft_q])
    q_skills, q_exp, q_soft = query_embs[0], query_embs[1], query_embs[2]

    candidates = [all_candidates[cid] for cid in top_candidate_ids if cid in all_candidates]

    skills_texts = [build_skills_text(c) for c in candidates]
    exp_texts = [build_experience_text(c) for c in candidates]
    soft_texts = [build_soft_signals_text(c) for c in candidates]

    skills_embs = encoder.encode(skills_texts)
    exp_embs = encoder.encode(exp_texts)
    soft_embs = encoder.encode(soft_texts)

    results = []
    for i, candidate in enumerate(candidates):
        sk = _cosine(q_skills, skills_embs[i])
        ex = _cosine(q_exp, exp_embs[i])
        soft = _cosine(q_soft, soft_embs[i])
        composite = compute_semantic_composite(sk, ex, soft, ideal_profile.dimension_weights)
        results.append((candidate.candidate_id, sk, ex, soft, composite))

    results.sort(key=lambda x: x[4], reverse=True)
    return results
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
pytest tests/test_stage3.py -v
```
Expected: `1 passed`

- [ ] **Step 5: Commit**

```bash
git add pipeline/stage3_reranker.py tests/test_stage3.py
git commit -m "feat: stage 3 Gemma multi-dimensional semantic re-scoring"
```

---

## Task 10: Pipeline Stage 4 — Redrob Signal Blending

**Files:**
- Create: `pipeline/stage4_signal_blender.py`
- Test: `tests/test_stage4.py`

**Interfaces:**
- Consumes: Stage 3 output `list[tuple[str, float, float, float, float]]`, `dict[str, Candidate]`, `config.settings`
- Produces: `pipeline.stage4_signal_blender.run_stage4(stage3_results: list[tuple], all_candidates: dict[str, Candidate]) -> list[CandidateScore]`
  — top-N `CandidateScore` objects sorted descending by `blended_score`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_stage4.py
import json, pytest
from models.candidate import Candidate
from models.scoring import CandidateScore
from pipeline.stage4_signal_blender import run_stage4

SAMPLE_PATH = "[PUB] India_runs_data_and_ai_challenge/India_runs_data_and_ai_challenge/sample_candidates.json"

def _load_sample_candidates() -> dict:
    candidates = {}
    with open(SAMPLE_PATH) as f:
        for line in f:
            line = line.strip()
            if line:
                c = Candidate.model_validate(json.loads(line))
                candidates[c.candidate_id] = c
    return candidates

def test_run_stage4_returns_candidate_scores():
    candidates = _load_sample_candidates()
    ids = list(candidates.keys())[:3]
    stage3_results = [
        (ids[0], 0.85, 0.80, 0.70, 0.81),
        (ids[1], 0.70, 0.65, 0.60, 0.67),
        (ids[2], 0.50, 0.45, 0.40, 0.47),
    ]

    results = run_stage4(stage3_results, candidates)

    assert len(results) <= len(stage3_results)
    for cs in results:
        assert isinstance(cs, CandidateScore)
        assert 0.0 <= cs.blended_score <= 1.0
        assert 0.0 <= cs.redrob_score <= 1.0

def test_run_stage4_sorted_descending():
    candidates = _load_sample_candidates()
    ids = list(candidates.keys())[:3]
    stage3_results = [
        (ids[0], 0.85, 0.80, 0.70, 0.81),
        (ids[1], 0.70, 0.65, 0.60, 0.67),
        (ids[2], 0.50, 0.45, 0.40, 0.47),
    ]

    results = run_stage4(stage3_results, candidates)
    scores = [cs.blended_score for cs in results]
    assert scores == sorted(scores, reverse=True)

def test_low_quality_candidates_flagged():
    candidates = _load_sample_candidates()
    cid = list(candidates.keys())[0]
    # Force low completeness
    candidates[cid].redrob_signals.profile_completeness_score = 20.0

    stage3_results = [(cid, 0.6, 0.6, 0.6, 0.6)]
    results = run_stage4(stage3_results, candidates)

    low_q = [cs for cs in results if cs.candidate_id == cid]
    assert len(low_q) == 1
    assert low_q[0].is_low_quality is True
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/test_stage4.py -v
```
Expected: `ModuleNotFoundError: No module named 'pipeline.stage4_signal_blender'`

- [ ] **Step 3: Write `pipeline/stage4_signal_blender.py`**

```python
from datetime import date
from models.candidate import Candidate
from models.scoring import CandidateScore
from scoring.redrob_signals import score_redrob
from config import settings

LOW_QUALITY_COMPLETENESS = 30.0
LOW_QUALITY_INACTIVE_DAYS = 180
LOW_QUALITY_SCORE_EXCEPTION = 0.90  # Skip cap if semantic score is exceptionally high

def _is_low_quality(candidate: Candidate, semantic_composite: float) -> bool:
    if semantic_composite >= LOW_QUALITY_SCORE_EXCEPTION:
        return False
    signals = candidate.redrob_signals
    if signals.profile_completeness_score < LOW_QUALITY_COMPLETENESS:
        return True
    days_inactive = (date.today() - signals.last_active_date).days
    if days_inactive > LOW_QUALITY_INACTIVE_DAYS:
        return True
    return False

def run_stage4(
    stage3_results: list[tuple[str, float, float, float, float]],
    all_candidates: dict[str, Candidate],
) -> list[CandidateScore]:
    """
    Blend semantic composite with Redrob signals.
    Returns top-N CandidateScore objects sorted descending by blended_score.
    """
    scores = []
    for cid, sk, ex, soft, semantic_composite in stage3_results:
        candidate = all_candidates.get(cid)
        if candidate is None:
            continue

        redrob_breakdown = score_redrob(candidate.redrob_signals)
        redrob_score = redrob_breakdown["redrob_composite"]

        blended = (
            settings.semantic_weight * semantic_composite
            + settings.redrob_weight * redrob_score
        )
        blended = round(min(1.0, max(0.0, blended)), 6)

        low_quality = _is_low_quality(candidate, semantic_composite)

        scores.append(CandidateScore(
            candidate_id=cid,
            skills_score=round(sk, 6),
            experience_score=round(ex, 6),
            soft_signals_score=round(soft, 6),
            semantic_composite=round(semantic_composite, 6),
            redrob_score=round(redrob_score, 6),
            blended_score=blended,
            is_low_quality=low_quality,
        ))

    scores.sort(key=lambda cs: cs.blended_score, reverse=True)
    return scores[:settings.final_candidates_n]
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
pytest tests/test_stage4.py -v
```
Expected: `3 passed`

- [ ] **Step 5: Commit**

```bash
git add pipeline/stage4_signal_blender.py tests/test_stage4.py
git commit -m "feat: stage 4 redrob signal blending"
```

---

## Task 11: Pipeline Stage 5 — Gemini Pro Final Ranking

**Files:**
- Create: `pipeline/stage5_llm_ranker.py`
- Test: `tests/test_stage5.py`

**Interfaces:**
- Consumes: `list[CandidateScore]`, `dict[str, Candidate]`, `IdealProfile`, `config.settings`, `prompts/final_ranking.txt`
- Produces: `pipeline.stage5_llm_ranker.run_stage5(shortlist: list[CandidateScore], all_candidates: dict[str, Candidate], ideal_profile: IdealProfile) -> list[FinalRankedCandidate]`
  — exactly 100 `FinalRankedCandidate` objects, ranks 1–100, scores non-increasing

- [ ] **Step 1: Write the failing test**

```python
# tests/test_stage5.py
import json, pytest
from unittest.mock import MagicMock, patch
from models.candidate import Candidate
from models.scoring import CandidateScore, FinalRankedCandidate
from models.ideal_profile import IdealProfile, DimensionWeights, ExperienceRequirements, SoftSignals
from pipeline.stage5_llm_ranker import run_stage5

SAMPLE_PATH = "[PUB] India_runs_data_and_ai_challenge/India_runs_data_and_ai_challenge/sample_candidates.json"

def _load_sample_candidates() -> dict:
    candidates = {}
    with open(SAMPLE_PATH) as f:
        for line in f:
            line = line.strip()
            if line:
                c = Candidate.model_validate(json.loads(line))
                candidates[c.candidate_id] = c
    return candidates

def _make_ideal_profile():
    return IdealProfile(
        required_skills=["Python"], preferred_skills=["PyTorch"],
        experience_requirements=ExperienceRequirements(
            min_years=3, seniority="senior", domains=["ML"],
            trajectory_signals=["grew into ML lead"]
        ),
        red_flags=["no production exp"],
        soft_signals=SoftSignals(summary_traits=["self-starter"], activities_and_awards=[], certifications=[]),
        dimension_weights=DimensionWeights(skills=0.4, experience=0.4, soft_signals=0.2)
    )

def _make_shortlist(candidates: dict) -> list[CandidateScore]:
    return [
        CandidateScore(
            candidate_id=cid,
            skills_score=0.8, experience_score=0.7, soft_signals_score=0.6,
            semantic_composite=0.74, redrob_score=0.65, blended_score=0.71,
            is_low_quality=False
        )
        for cid in list(candidates.keys())[:3]
    ]

def test_run_stage5_returns_final_ranked(monkeypatch):
    candidates = _load_sample_candidates()
    shortlist = _make_shortlist(candidates)
    ideal = _make_ideal_profile()

    mock_response_data = [
        {"candidate_id": cs.candidate_id, "rank": i+1,
         "score": round(0.9 - i * 0.05, 2), "reasoning": "Strong ML fit."}
        for i, cs in enumerate(shortlist)
    ]

    mock_model = MagicMock()
    mock_resp = MagicMock()
    mock_resp.text = json.dumps(mock_response_data)
    mock_model.generate_content.return_value = mock_resp

    monkeypatch.setattr("pipeline.stage5_llm_ranker._get_model", lambda: mock_model)

    results = run_stage5(shortlist, candidates, ideal)

    assert len(results) == len(shortlist)
    for frc in results:
        assert isinstance(frc, FinalRankedCandidate)
        assert frc.reasoning
    ranks = sorted(frc.rank for frc in results)
    assert ranks == list(range(1, len(shortlist) + 1))

def test_run_stage5_scores_non_increasing(monkeypatch):
    candidates = _load_sample_candidates()
    shortlist = _make_shortlist(candidates)
    ideal = _make_ideal_profile()

    mock_response_data = [
        {"candidate_id": cs.candidate_id, "rank": i+1,
         "score": round(0.9 - i * 0.05, 2), "reasoning": "Good fit."}
        for i, cs in enumerate(shortlist)
    ]
    mock_model = MagicMock()
    mock_resp = MagicMock()
    mock_resp.text = json.dumps(mock_response_data)
    mock_model.generate_content.return_value = mock_resp

    monkeypatch.setattr("pipeline.stage5_llm_ranker._get_model", lambda: mock_model)

    results = run_stage5(shortlist, candidates, ideal)
    results_sorted = sorted(results, key=lambda x: x.rank)
    scores = [r.score for r in results_sorted]
    assert scores == sorted(scores, reverse=True)
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/test_stage5.py -v
```
Expected: `ModuleNotFoundError: No module named 'pipeline.stage5_llm_ranker'`

- [ ] **Step 3: Write `pipeline/stage5_llm_ranker.py`**

```python
import json
from pathlib import Path
import google.generativeai as genai
from config import settings
from models.candidate import Candidate
from models.scoring import CandidateScore, FinalRankedCandidate
from models.ideal_profile import IdealProfile

_PROMPT_PATH = Path("prompts/final_ranking.txt")
BATCH_SIZE = 50

def _get_model():
    genai.configure(api_key=settings.google_api_key)
    return genai.GenerativeModel(settings.gemini_pro_model)

def _candidate_summary(cs: CandidateScore, candidate: Candidate) -> dict:
    top_skills = [
        {"name": s.name, "proficiency": s.proficiency}
        for s in candidate.skills[:5]
    ]
    trajectory = [
        {"title": e.title, "company": e.company, "industry": e.industry}
        for e in candidate.career_history[:2]
    ]
    return {
        "candidate_id": cs.candidate_id,
        "current_title": candidate.profile.current_title,
        "years_of_experience": candidate.profile.years_of_experience,
        "headline": candidate.profile.headline,
        "top_skills": top_skills,
        "career_trajectory": trajectory,
        "scores": {
            "skills": cs.skills_score,
            "experience": cs.experience_score,
            "soft_signals": cs.soft_signals_score,
            "semantic_composite": cs.semantic_composite,
            "redrob_engagement": cs.redrob_score,
        },
        "low_quality_flag": cs.is_low_quality,
    }

def _call_llm_batch(
    batch: list[CandidateScore],
    all_candidates: dict[str, Candidate],
    ideal_profile: IdealProfile,
    rank_offset: int,
) -> list[FinalRankedCandidate]:
    template = _PROMPT_PATH.read_text(encoding="utf-8")
    summaries = [_candidate_summary(cs, all_candidates[cs.candidate_id]) for cs in batch]
    prompt = (
        template
        .replace("{{total}}", str(len(batch)))
        .replace("{{ideal_profile_json}}", json.dumps(ideal_profile.model_dump(), indent=2))
        .replace("{{candidates_json}}", json.dumps(summaries, indent=2))
    )

    model = _get_model()
    response = model.generate_content(prompt)
    raw = response.text.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]

    ranked = json.loads(raw)
    results = []
    for item in ranked:
        results.append(FinalRankedCandidate(
            candidate_id=item["candidate_id"],
            rank=item["rank"] + rank_offset,
            score=float(item["score"]),
            reasoning=item["reasoning"],
        ))
    return results

def _enforce_non_increasing_scores(results: list[FinalRankedCandidate]) -> list[FinalRankedCandidate]:
    """Ensure scores are non-increasing by rank after LLM output."""
    sorted_results = sorted(results, key=lambda x: x.rank)
    for i in range(1, len(sorted_results)):
        if sorted_results[i].score > sorted_results[i - 1].score:
            sorted_results[i] = sorted_results[i].model_copy(
                update={"score": sorted_results[i - 1].score}
            )
    return sorted_results

def run_stage5(
    shortlist: list[CandidateScore],
    all_candidates: dict[str, Candidate],
    ideal_profile: IdealProfile,
) -> list[FinalRankedCandidate]:
    """Batch LLM ranking → merge → enforce constraints → return top-100."""
    # Split into batches of BATCH_SIZE
    batches = [shortlist[i:i + BATCH_SIZE] for i in range(0, len(shortlist), BATCH_SIZE)]

    batch_results = []
    for i, batch in enumerate(batches):
        results = _call_llm_batch(batch, all_candidates, ideal_profile, rank_offset=0)
        batch_results.extend(results)

    # Re-rank across all batches: sort by score descending, assign ranks 1..N
    batch_results.sort(key=lambda x: x.score, reverse=True)
    final = []
    for i, item in enumerate(batch_results[:100]):
        final.append(FinalRankedCandidate(
            candidate_id=item.candidate_id,
            rank=i + 1,
            score=item.score,
            reasoning=item.reasoning,
        ))

    return _enforce_non_increasing_scores(final)
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
pytest tests/test_stage5.py -v
```
Expected: `2 passed`

- [ ] **Step 5: Commit**

```bash
git add pipeline/stage5_llm_ranker.py tests/test_stage5.py
git commit -m "feat: stage 5 Gemini Pro final ranking with reasoning"
```

---

## Task 12: Output Formatter + Validator

**Files:**
- Create: `output/formatter.py`
- Create: `output/validator.py`
- Create: `scripts/validate.py`
- Test: `tests/test_output.py`

**Interfaces:**
- Consumes: `list[FinalRankedCandidate]`
- Produces:
  - `output.formatter.write_submission(results: list[FinalRankedCandidate], output_path: str) -> None`
  - `output.validator.validate_submission(csv_path: str) -> list[str]` — returns list of error strings (empty = valid)

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_output.py
import csv, tempfile, os, pytest
from models.scoring import FinalRankedCandidate
from output.formatter import write_submission
from output.validator import validate_submission

def _make_100_results() -> list[FinalRankedCandidate]:
    return [
        FinalRankedCandidate(
            candidate_id=f"CAND_{str(i).zfill(7)}",
            rank=i,
            score=round(1.0 - (i - 1) * 0.009, 4),
            reasoning=f"Candidate {i} reasoning."
        )
        for i in range(1, 101)
    ]

def test_write_submission_creates_valid_csv():
    results = _make_100_results()
    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
        path = f.name
    try:
        write_submission(results, path)
        with open(path, newline="", encoding="utf-8") as f:
            rows = list(csv.reader(f))
        assert rows[0] == ["candidate_id", "rank", "score", "reasoning"]
        assert len(rows) == 101  # header + 100 data rows
        assert rows[1][0] == "CAND_0000001"
        assert rows[1][1] == "1"
    finally:
        os.unlink(path)

def test_validate_submission_passes_valid_csv():
    results = _make_100_results()
    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
        path = f.name
    try:
        write_submission(results, path)
        errors = validate_submission(path)
        assert errors == []
    finally:
        os.unlink(path)

def test_validate_submission_catches_duplicate_rank():
    results = _make_100_results()
    results[1] = FinalRankedCandidate(
        candidate_id="CAND_0000099", rank=1,  # duplicate rank 1
        score=0.9, reasoning="test"
    )
    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
        path = f.name
    try:
        write_submission(results, path)
        errors = validate_submission(path)
        assert any("duplicate" in e.lower() or "rank" in e.lower() for e in errors)
    finally:
        os.unlink(path)
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/test_output.py -v
```
Expected: `ModuleNotFoundError: No module named 'output.formatter'`

- [ ] **Step 3: Write `output/formatter.py`**

```python
import csv
from models.scoring import FinalRankedCandidate

def write_submission(results: list[FinalRankedCandidate], output_path: str) -> None:
    """Write final ranked candidates to submission CSV."""
    sorted_results = sorted(results, key=lambda x: x.rank)
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["candidate_id", "rank", "score", "reasoning"])
        for r in sorted_results:
            writer.writerow([r.candidate_id, r.rank, f"{r.score:.4f}", r.reasoning])
```

- [ ] **Step 4: Write `output/validator.py`**

```python
import csv, re
from pathlib import Path

REQUIRED_HEADER = ["candidate_id", "rank", "score", "reasoning"]
CANDIDATE_ID_PATTERN = re.compile(r"^CAND_[0-9]{7}$")

def validate_submission(csv_path: str) -> list[str]:
    """Returns list of error strings. Empty list = valid submission."""
    errors = []
    path = Path(csv_path)

    try:
        with open(path, "r", encoding="utf-8", newline="") as f:
            reader = csv.reader(f)
            header = next(reader, None)
            if header != REQUIRED_HEADER:
                errors.append(f"Header must be {REQUIRED_HEADER}, got {header}")
                return errors
            data_rows = [row for row in reader if any(c.strip() for c in row)]
    except Exception as e:
        return [f"Cannot read file: {e}"]

    if len(data_rows) != 100:
        errors.append(f"Expected 100 data rows, got {len(data_rows)}")

    seen_ids, seen_ranks, by_rank = set(), set(), []

    for i, cells in enumerate(data_rows):
        if len(cells) != 4:
            errors.append(f"Row {i+2}: expected 4 columns, got {len(cells)}")
            continue
        cid, rank_s, score_s, _ = cells
        cid = cid.strip()

        if not CANDIDATE_ID_PATTERN.match(cid):
            errors.append(f"Row {i+2}: invalid candidate_id '{cid}'")
        elif cid in seen_ids:
            errors.append(f"Row {i+2}: duplicate candidate_id '{cid}'")
        else:
            seen_ids.add(cid)

        try:
            rank = int(rank_s.strip())
            if not 1 <= rank <= 100:
                errors.append(f"Row {i+2}: rank {rank} out of range 1-100")
            elif rank in seen_ranks:
                errors.append(f"Row {i+2}: duplicate rank {rank}")
            else:
                seen_ranks.add(rank)
        except ValueError:
            errors.append(f"Row {i+2}: rank must be integer, got '{rank_s}'")
            rank = None

        try:
            score = float(score_s.strip())
            if cid and rank:
                by_rank.append((rank, score))
        except ValueError:
            errors.append(f"Row {i+2}: score must be float, got '{score_s}'")

    missing_ranks = set(range(1, 101)) - seen_ranks
    if missing_ranks:
        errors.append(f"Missing ranks: {sorted(missing_ranks)}")

    by_rank.sort()
    for i in range(len(by_rank) - 1):
        r1, s1 = by_rank[i]
        r2, s2 = by_rank[i + 1]
        if s1 < s2:
            errors.append(f"Non-monotonic scores: rank {r1} score {s1} < rank {r2} score {s2}")

    return errors
```

- [ ] **Step 5: Write `scripts/validate.py`**

```python
#!/usr/bin/env python3
"""Validate a submission CSV against challenge rules."""
import sys
from output.validator import validate_submission

def main():
    if len(sys.argv) != 2:
        print("Usage: python scripts/validate.py <submission.csv>")
        sys.exit(1)
    errors = validate_submission(sys.argv[1])
    if errors:
        print(f"Validation failed ({len(errors)} issue(s)):")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)
    print("Submission is valid.")

if __name__ == "__main__":
    main()
```

- [ ] **Step 6: Run tests to verify they pass**

```bash
pytest tests/test_output.py -v
```
Expected: `3 passed`

- [ ] **Step 7: Commit**

```bash
git add output/ scripts/validate.py tests/test_output.py
git commit -m "feat: submission formatter and validator"
```

---

## Task 13: Main Orchestrator

**Files:**
- Create: `main.py`
- Test: integration smoke test (see step 4)

**Interfaces:**
- Consumes: all pipeline stages, `data.loader.stream_candidates`, `config.settings`
- Produces: `submission.csv` at specified output path

- [ ] **Step 1: Write `main.py`**

```python
#!/usr/bin/env python3
"""
Main pipeline orchestrator.

Usage:
    python main.py --jd <path_to_jd.txt> --output submission.csv

Stages 1 and 2 run in parallel via threading.
"""
import argparse, json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from config import settings
from data.loader import stream_candidates
from pipeline.stage1_prefilter import run_stage1
from pipeline.stage2_ideal_profile import run_stage2
from pipeline.stage3_reranker import run_stage3
from pipeline.stage4_signal_blender import run_stage4
from pipeline.stage5_llm_ranker import run_stage5
from output.formatter import write_submission
from output.validator import validate_submission

def load_candidates_by_id(candidate_ids: list[str], candidates_file: str) -> dict:
    """Load only the candidates we need from disk by streaming."""
    needed = set(candidate_ids)
    result = {}
    for candidate in stream_candidates(candidates_file):
        if candidate.candidate_id in needed:
            result[candidate.candidate_id] = candidate
        if len(result) == len(needed):
            break
    return result

def main():
    parser = argparse.ArgumentParser(description="AI Candidate Ranking Pipeline")
    parser.add_argument("--jd", required=True, help="Path to job description text file")
    parser.add_argument("--output", default="submission.csv", help="Output CSV path")
    parser.add_argument("--candidates", default=settings.candidates_file)
    args = parser.parse_args()

    jd_text = Path(args.jd).read_text(encoding="utf-8")
    print(f"[1/5] Running Stage 1 (miniLM pre-filter) and Stage 2 (ideal profile) in parallel...")

    with ThreadPoolExecutor(max_workers=2) as executor:
        future_stage1 = executor.submit(run_stage1, jd_text)
        future_stage2 = executor.submit(run_stage2, jd_text)
        top_candidate_ids = future_stage1.result()
        ideal_profile = future_stage2.result()

    print(f"  Stage 1: {len(top_candidate_ids)} candidates pre-filtered")
    print(f"  Stage 2: ideal profile generated ({len(ideal_profile.required_skills)} required skills)")

    print(f"[2/5] Loading top-{len(top_candidate_ids)} candidate profiles from disk...")
    all_candidates = load_candidates_by_id(top_candidate_ids, args.candidates)
    print(f"  Loaded {len(all_candidates)} candidates")

    print(f"[3/5] Running Stage 3 (Gemma multi-dim re-scoring)...")
    stage3_results = run_stage3(ideal_profile, top_candidate_ids, all_candidates)
    print(f"  Scored {len(stage3_results)} candidates")

    print(f"[4/5] Running Stage 4 (Redrob signal blending)...")
    shortlist = run_stage4(stage3_results, all_candidates)
    print(f"  Shortlisted {len(shortlist)} candidates")

    print(f"[5/5] Running Stage 5 (Gemini Pro final ranking)...")
    final_results = run_stage5(shortlist, all_candidates, ideal_profile)
    print(f"  Final ranking: {len(final_results)} candidates")

    write_submission(final_results, args.output)
    errors = validate_submission(args.output)
    if errors:
        print(f"WARNING: Submission validation failed:")
        for e in errors:
            print(f"  - {e}")
    else:
        print(f"Submission written and validated: {args.output}")

if __name__ == "__main__":
    main()
```

- [ ] **Step 2: Run all unit tests to verify nothing is broken**

```bash
pytest tests/ -v
```
Expected: all tests pass

- [ ] **Step 3: Run smoke test on sample candidates**

First precompute embeddings for sample candidates:
```bash
python scripts/precompute_embeddings.py --candidates "[PUB] India_runs_data_and_ai_challenge/India_runs_data_and_ai_challenge/sample_candidates.json"
```

Then copy sample JD text from `job_description.docx` into a plain text file:
```bash
# Create a minimal JD for smoke test
echo "We are hiring a Senior AI/ML Engineer. Required: Python, PyTorch, LLMs, 5+ years experience in ML systems. Nice to have: MLflow, Kubernetes, distributed training." > /tmp/test_jd.txt
```

Run the pipeline on sample candidates (only 5 candidates, will return fewer than 100):
```bash
python main.py --jd /tmp/test_jd.txt --candidates "[PUB] India_runs_data_and_ai_challenge/India_runs_data_and_ai_challenge/sample_candidates.json" --output /tmp/sample_submission.csv
```

Expected output:
```
[1/5] Running Stage 1 and Stage 2 in parallel...
  Stage 1: N candidates pre-filtered
  Stage 2: ideal profile generated
[2/5] Loading candidates...
[3/5] Stage 3...
[4/5] Stage 4...
[5/5] Stage 5...
Submission written and validated: /tmp/sample_submission.csv
```

- [ ] **Step 4: Run full precompute on 100k candidates (takes 30-60 min)**

```bash
python scripts/precompute_embeddings.py
```

- [ ] **Step 5: Commit**

```bash
git add main.py
git commit -m "feat: main pipeline orchestrator with parallel stage 1+2"
```

---

## Task 14: Full Pipeline Run + Submission

**Files:**
- No new files — end-to-end execution

- [ ] **Step 1: Ensure FAISS index is precomputed for all 100k**

```bash
ls cache/embeddings_cache/
# Should show: minilm.index.faiss  minilm.index.ids  candidate_ids.txt
```

- [ ] **Step 2: Read job description from docx and save as plain text**

```bash
python3 -c "
import docx
doc = docx.Document('[PUB] India_runs_data_and_ai_challenge/India_runs_data_and_ai_challenge/job_description.docx')
text = '\n'.join(p.text for p in doc.paragraphs if p.text.strip())
with open('job_description.txt', 'w') as f:
    f.write(text)
print('Done. First 200 chars:', text[:200])
"
# If python-docx not installed: pip install python-docx
```

- [ ] **Step 3: Run full pipeline**

```bash
python main.py --jd job_description.txt --output submission.csv
```

- [ ] **Step 4: Validate output**

```bash
python scripts/validate.py submission.csv
```
Expected: `Submission is valid.`

- [ ] **Step 5: Inspect top 10 results**

```bash
head -11 submission.csv
```

- [ ] **Step 6: Final commit**

```bash
git add submission.csv job_description.txt
git commit -m "feat: final submission CSV generated and validated"
```

---

## Self-Review Against Spec

| Spec Requirement | Task |
|---|---|
| Stage 1: miniLM broad pre-filter → top 2500 | Task 4, 7 |
| Stage 2: Gemini Flash ideal candidate profile | Task 8 |
| Stage 1 + 2 parallel | Task 13 |
| Stage 3: Gemma 300M 3-dim embedding + composite | Task 4, 9 |
| Stage 4: 6 Redrob sub-signals + blended score | Task 5, 10 |
| Stage 5: Gemini Pro batched final ranking + reasoning | Task 11 |
| Pydantic models at every stage boundary | Task 2 |
| Streaming NDJSON loader (no full RAM load) | Task 3 |
| Ideal profile caching (JD hash) | Task 8 |
| Low-quality candidate flagging | Task 10 |
| github_activity_score=-1 → 0 | Task 5 |
| offer_acceptance_rate=-1 → 0.5 neutral | Task 5 |
| Submission CSV validation | Task 12 |
| Scores non-increasing by rank | Task 11, 12 |
| All config via config.py/.env | Task 1 |
| Prompt files as plain text | Task 1 |
| Hallucination prevention prompt instruction | Task 1 (prompt) |
| Offline precompute script | Task 6 |
